@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0LaptopCheck.ps1" %*
set "inspectionExit=%ERRORLEVEL%"
if not "%inspectionExit%"=="0" echo Inspection ended with code %inspectionExit%.
exit /b %inspectionExit%
