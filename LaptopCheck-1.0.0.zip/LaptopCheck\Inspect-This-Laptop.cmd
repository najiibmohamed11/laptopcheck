@echo off
call "%~dp0Check-Laptop.cmd" %*
echo.
pause
