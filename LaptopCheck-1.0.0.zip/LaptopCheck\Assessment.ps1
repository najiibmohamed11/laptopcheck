﻿function Get-Field {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
    } else {
        $p = $Object.PSObject.Properties[$Name]
        if ($null -ne $p) { return $p.Value }
    }
    return $Default
}

function Get-IntelGeneration {
    param([string]$Name)
    # G7 in i7-1165G7 is a graphics suffix, not the CPU generation.
    if ($Name -match '(?i)\bi[3579][ -]+(\d{4,5})(?:\b|[A-Z])') {
        $digits = $Matches[1]
        $prefix = [int]$digits.Substring(0, 2)
        if ($digits.Length -eq 5 -or ($prefix -ge 10 -and $prefix -le 14)) {
            return [int]$digits.Substring(0, 2)
        }
        return [int]$digits.Substring(0, 1)
    }
    # Modern Core / Core Ultra and AMD names require their own identification.
    return $null
}

function New-Finding {
    param([string]$Area, [string]$Severity, [string]$Title, [string]$Evidence, [string]$Next)
    [pscustomobject]@{ Area=$Area; Severity=$Severity; Title=$Title; Evidence=$Evidence; Next=$Next }
}

function Get-Assessment {
    param($Data, [int]$MinRamGB=16, [int]$MinDiskGB=500, [int]$MinIntelGeneration=11, [int]$MinIntelTier=7)
    $findings = New-Object 'System.Collections.Generic.List[object]'
    $requirements = New-Object 'System.Collections.Generic.List[object]'
    $cpu = Get-Field $Data 'CPU'
    $cpuName = [string](Get-Field $cpu 'Name')
    $gen = Get-IntelGeneration $cpuName
    $cpuStatus = 'UNKNOWN'
    if ($null -ne $gen) {
        $cpuStatus = if ($gen -ge $MinIntelGeneration) { 'MEETS' } else { 'BELOW' }
    }
    $requirements.Add([pscustomobject]@{Name='CPU generation';Status=$cpuStatus;Actual=$cpuName;Target="Intel generation $MinIntelGeneration or newer"})
    $tier = $null
    if ($cpuName -match '(?i)\bi([3579])[ -]') { $tier = [int]$Matches[1] }
    $tierStatus = if ($null -eq $tier) {'UNKNOWN'} elseif ($tier -ge $MinIntelTier) {'MEETS'} else {'BELOW'}
    $requirements.Add([pscustomobject]@{Name='CPU marketing tier';Status=$tierStatus;Actual=$cpuName;Target="Core i$MinIntelTier or higher (not a performance benchmark)"})
    if ($cpuStatus -eq 'UNKNOWN') {
        $findings.Add((New-Finding 'CPU' 'unknown' 'CPU target needs manual comparison' $cpuName 'Core / Core Ultra / Ryzen naming is not mapped to Intel i-series generations. Compare the exact CPU; do not infer a generation from its marketing tier.'))
    }
    $ram = Get-Field (Get-Field $Data 'Memory') 'InstalledGB'
    $ramStatus = if ($null -eq $ram) {'UNKNOWN'} elseif ([double]$ram + 0.1 -ge $MinRamGB) {'MEETS'} else {'BELOW'}
    $requirements.Add([pscustomobject]@{Name='Installed RAM';Status=$ramStatus;Actual=$(if($null -eq $ram){'Unavailable'}else{"$ram GiB"});Target="$MinRamGB GiB"})
    $osDisk = Get-Field $Data 'OSDisk'
    $diskBytes = Get-Field $osDisk 'SizeBytes'
    # Sellers quote decimal GB: a 512GB drive is about 477GiB in Windows.
    $diskStatus = if ($null -eq $diskBytes) {'UNKNOWN'} elseif ([double]$diskBytes -ge $MinDiskGB * 1e9) {'MEETS'} else {'BELOW'}
    $diskActual = if ($null -eq $diskBytes) {'Unavailable'} else { '{0:N1} GB decimal / {1:N1} GiB' -f ($diskBytes/1e9),($diskBytes/1GB) }
    $requirements.Add([pscustomobject]@{Name='Windows physical disk capacity';Status=$diskStatus;Actual=$diskActual;Target="$MinDiskGB GB decimal"})
    $bus = [string](Get-Field $osDisk 'BusType')
    $mediaType = [string](Get-Field $osDisk 'MediaType')
    $mediaStatus = if ($bus -eq 'NVMe' -or $mediaType -eq 'SSD') {'MEETS'} elseif ($mediaType -eq 'HDD') {'BELOW'} else {'UNKNOWN'}
    $requirements.Add([pscustomobject]@{Name='Windows drive type';Status=$mediaStatus;Actual="$mediaType / $bus";Target='SSD'})
    if ($bus -and $bus -ne 'NVMe') {
        $findings.Add((New-Finding 'Storage' 'note' 'Verify the advertised storage interface' "Windows disk bus: $bus" 'RAID/controller modes can hide NVMe. Confirm the exact drive and controller; do not infer NVMe from the word SSD alone.'))
    }

    $batteries = @(Get-Field $Data 'Batteries' @())
    if ($batteries.Count -eq 0) {
        $portable=Get-Field (Get-Field $Data 'Computer') 'IsPortable'
        if ($null -ne $portable -and $portable -eq $false) {
            $findings.Add((New-Finding 'Battery' 'note' 'No battery report on a non-mobile system' 'Windows does not classify this system as mobile.' 'Battery assessment is not applicable unless this particular unit should contain one.'))
        } else {
            $findings.Add((New-Finding 'Battery' 'unknown' 'No battery capacity information collected' 'No readable battery-report records.' 'For a laptop, verify battery presence and health separately; this is not a pass.'))
        }
    }
    foreach ($b in $batteries) {
        $design = Get-Field $b 'DesignMWh'; $full = Get-Field $b 'FullMWh'
        if ($null -eq $design -or $null -eq $full -or $design -le 0 -or $full -le 0) {
            $findings.Add((New-Finding 'Battery' 'unknown' 'Battery wear estimate unavailable' ([string](Get-Field $b 'Name')) 'Capacity fields are missing or invalid. Run OEM battery diagnostics.'))
            continue
        }
        $health = [math]::Round(100.0*$full/$design,1)
        $sev = if ($health -lt 60) {'warning'} elseif ($health -lt 80) {'warning'} elseif ($health -gt 110) {'unknown'} else {'note'}
        $findings.Add((New-Finding 'Battery' $sev "Reported battery capacity: $health% of design" ("Full $full mWh; design $design mWh; cycles: " + (Get-Field $b 'Cycles' 'unavailable')) 'Capacity is a firmware estimate, not an internal-resistance or safety test. Budget for replacement when worn; inspect for swelling and test unplugged operation.'))
    }

    $smart = @(Get-Field $Data 'Smart' @())
    $readableSmart = 0
    foreach ($drive in $smart) {
        $j = Get-Field $drive 'Data'
        if ($null -eq $j) { continue }
        $nvme = Get-Field $j 'nvme_smart_health_information_log'
        $status = Get-Field $j 'smart_status'
        $passed = Get-Field $status 'passed'
        if ($null -ne $nvme -or $null -ne $passed) { $readableSmart++ }
        $model = [string](Get-Field $j 'model_name' (Get-Field $drive 'Device'))
        if ($passed -eq $false -and $null -ne $passed) {
            $findings.Add((New-Finding 'Storage' 'critical' 'Drive reports a failed SMART health check' $model 'Do not rely on this drive for a purchase without replacement and retesting.'))
        }
        if ($null -ne $nvme) {
            $critical = Get-Field $nvme 'critical_warning'
            $media = Get-Field $nvme 'media_errors'
            $used = Get-Field $nvme 'percentage_used'
            if ($null -ne $critical -and [long]$critical -ne 0) {
                $findings.Add((New-Finding 'Storage' 'critical' 'NVMe critical-warning flags are set' "$model; flags=$critical" 'Decode the warning and resolve it before purchase.'))
            }
            if ($null -ne $media -and [long]$media -gt 0) {
                $findings.Add((New-Finding 'Storage' 'critical' 'NVMe media/data-integrity errors recorded' "$model; media errors=$media" 'Investigate drive health and require replacement/retesting rather than trusting a Healthy label.'))
            }
            if ($null -ne $used -and [double]$used -ge 50) {
                $severity = if ([double]$used -ge 100) {'critical'} else {'warning'}
                $findings.Add((New-Finding 'Storage' $severity 'Substantial SSD endurance consumption reported' "$model; percentage used=$used" 'This estimates endurance consumption, not percent of files used or guaranteed remaining life.'))
            }
            $unsafe = Get-Field $nvme 'unsafe_shutdowns'
            if ($null -ne $unsafe -and [long]$unsafe -gt 0) {
                $findings.Add((New-Finding 'Storage' 'note' 'SSD records unsafe shutdowns' "$model; count=$unsafe" 'This does not identify the cause or prove motherboard failure. Correlate with boot behavior, crash dumps and Windows events.'))
            }
            $commandErrors = Get-Field $nvme 'num_err_log_entries'
            if ($null -ne $commandErrors -and [long]$commandErrors -gt 0) {
                $findings.Add((New-Finding 'Storage' 'note' 'NVMe command-error log has entries' "$model; count=$commandErrors" 'Unsupported monitoring commands can create these entries. The count alone is not proof of damaged media.'))
            }
        }
        $ata=Get-Field $j 'ata_smart_attributes'
        foreach($attribute in @(Get-Field $ata 'table' @())) {
            $id=Get-Field $attribute 'id'
            $raw=Get-Field (Get-Field $attribute 'raw') 'value'
            if ($id -in 5,197,198 -and $null -ne $raw -and [double]$raw -gt 0) {
                $findings.Add((New-Finding 'Storage' 'warning' 'ATA media-related attribute needs review' ("$model; attribute $id "+(Get-Field $attribute 'name')+"; raw=$raw") 'Attribute meanings/units can be vendor-specific. Review manufacturer guidance and actual sector/uncorrectable-error evidence before buying.'))
            }
        }
        $temperature = Get-Field (Get-Field $j 'temperature') 'current'
        if ($null -ne $temperature -and [double]$temperature -ge 75) {
            $findings.Add((New-Finding 'Cooling' 'warning' 'Drive temperature warrants checking' "$model; current temperature=$temperature C" 'Check the model-specific limits and cooling under ordinary use. Temperature alone does not prove a thermal shutdown.'))
        }
    }
    if ($readableSmart -eq 0) {
        $findings.Add((New-Finding 'Storage' 'unknown' 'Detailed SMART health could not be assessed' 'No supported readable SMART health payload.' 'Run elevated with the bundled smartctl or use OEM diagnostics. Blank Windows counters do not mean zero errors.'))
    }

    $devices = @(Get-Field $Data 'DeviceProblems' @())
    if ($devices.Count -gt 0) {
        $findings.Add((New-Finding 'Drivers' 'warning' 'Device Manager problem devices found' (($devices | ForEach-Object {"$($_.Name) [code $($_.Code)]"}) -join '; ') 'Match hardware IDs to manufacturer drivers. A missing generic chipset INF does not by itself establish failing power or cooling hardware.'))
    }
    foreach ($group in (@(Get-Field $Data 'Events' @()) | Group-Object { Get-Field $_ 'Kind' })) {
        $count = $group.Count
        $latest = $group.Group[0].Time
        switch ($group.Name) {
            'UnexpectedRestart' { $findings.Add((New-Finding 'Stability' 'warning' 'Unclean restart events recorded' "$count records; latest $latest" 'Event 41 without a bugcheck is not proof of electrical power loss. It can follow hangs, forced shutdowns or an unrecorded crash. Events can describe the same incident.')) }
            'Bugcheck' { $findings.Add((New-Finding 'Stability' 'warning' 'Windows crash evidence recorded' "$count records; latest $latest" 'Analyze the saved dump to identify the failing path. A 0x124 code does not automatically identify the CPU; 0x154 does not alone prove a failed SSD.')) }
            'Storage' { $findings.Add((New-Finding 'Storage' 'warning' 'Storage timeouts, retries or errors recorded' "$count records; latest $latest" 'Investigate controller/driver/firmware, drive and connection. Test the actual unit; a SMART pass does not exclude intermittent faults.')) }
            'HardwareError' { $findings.Add((New-Finding 'Hardware' 'warning' 'Windows hardware-error reports found' "$count records; latest $latest" 'Read the error record and correlate it with diagnostics. The provider name alone does not identify a replaceable part.')) }
            'CriticalBattery' { $findings.Add((New-Finding 'Battery' 'warning' 'Critical-battery triggers recorded' "$count records; latest $latest" 'Check battery readings, adapter identification, cable and charging. A trigger is not proof of a particular charger fault.')) }
            'Thermal' { $findings.Add((New-Finding 'Cooling' 'warning' 'Thermal-related power events recorded' "$count records; latest $latest" 'Inspect the exact event and cooling system; confirm the shutdown circumstances.')) }
            'FirmwareLimit' { $findings.Add((New-Finding 'Cooling' 'note' 'Firmware limited CPU performance' "$count records; latest $latest" 'Event 37 is not unique to overheating or missing drivers; power-source limits can also matter.')) }
            'LogCleared' { $findings.Add((New-Finding 'History' 'unknown' 'A log-clear event is retained' "$count records; latest $latest" 'Older history may be missing. This is not proof of dishonest behavior, and an empty log is not proof of reliability.')) }
        }
    }
    $memoryTests = @(Get-Field $Data 'MemoryTests' @())
    if ($memoryTests.Count -eq 0) {
        $findings.Add((New-Finding 'Memory' 'unknown' 'No saved Windows memory-test result' 'No result was collected.' 'Run a proper preboot memory test with seller permission. Absence of WHEA/RAM errors is not a completed test.'))
    } else {
        $latestTest = $memoryTests[0]
        $completion = [string](Get-Field $latestTest 'Completion')
        $bad = Get-Field $latestTest 'BadPages'
        if (($null -ne $bad -and [long]$bad -gt 0) -or $completion -match '(?i)fail') {
            $findings.Add((New-Finding 'Memory' 'critical' 'Saved memory test reports a failure' (Get-Field $latestTest 'Message') 'Resolve and retest before purchase.'))
        } elseif ($completion -eq 'Pass') {
            $findings.Add((New-Finding 'Memory' 'note' 'A saved memory test passed' ("Recorded " + (Get-Field $latestTest 'Time')) 'This is historical evidence from this installation, not a new test or a guarantee against intermittent faults.'))
        } else {
            $findings.Add((New-Finding 'Memory' 'unknown' 'Memory-test result needs interpretation' (Get-Field $latestTest 'Message') 'Inspect the original event; do not assume success.'))
        }
    }
    $samples = @(Get-Field $Data 'Samples' @())
    $hotZones=@(foreach($s in $samples){foreach($z in @(Get-Field $s 'ThermalZones' @())){if((Get-Field $z 'Celsius' 0) -ge 95){$z}}})
    if ($hotZones.Count) {
        $findings.Add((New-Finding 'Cooling' 'warning' 'A high firmware thermal-zone reading was captured' (($hotZones | ForEach-Object {"$($_.Zone): $($_.Celsius) C"} | Select-Object -Unique) -join '; ') 'Check fan operation and independent temperature telemetry. ACPI zones can be stale; this does not prove the CPU core temperature or a thermal shutdown.'))
    }
    if (@($samples | Where-Object { $_.AC -eq $true -and $_.Discharging -eq $true }).Count -gt 0) {
        $findings.Add((New-Finding 'Power' 'warning' 'Battery discharging with AC detected in this sample' 'At least one captured sample reported both states.' 'Check correct adapter wattage and charging behavior. Some systems supplement adapter power briefly; this does not alone identify a failed charger.'))
    }
    $manual = @(Get-Field $Data 'ManualChecks' @())
    foreach ($check in $manual) {
        if ($check.Result -eq 'FAIL') {
            $findings.Add((New-Finding 'Physical check' 'warning' ('Manual check failed: '+$check.Name) 'Reported during this inspection.' 'Inspect the defect and repair cost before making a decision.'))
        }
    }
    $cs = Get-Field $Data 'Computer'
    if ((Get-Field $cs 'DomainJoined') -eq $true) {
        $findings.Add((New-Finding 'Ownership/setup' 'warning' 'Windows currently reports domain membership' 'Win32_ComputerSystem.PartOfDomain=True' 'Require the seller to remove organizational management legitimately. A reset with internet access is still needed to check enrollment; an offline scan cannot clear Autopilot.'))
    }
    $setup=Get-Field $Data 'Setup'
    foreach($password in @(Get-Field $setup 'HPBiosPasswordIndicators' @())) {
        if ((Get-Field $password 'IsSet') -in 1,'1',$true) {
            $findings.Add((New-Finding 'Ownership/setup' 'warning' 'Firmware password presence reported' ([string](Get-Field $password 'Name')) 'Have the seller demonstrate authorized access and remove unknown firmware passwords before purchase. This tool cannot clear them.'))
        }
    }
    if ((Get-Field $setup 'CurrentEnrollmentIndicators' 0) -gt 0) {
        $findings.Add((New-Finding 'Ownership/setup' 'warning' 'Current management/enrollment indicators exist' ([string](Get-Field $setup 'CurrentEnrollmentIndicators')) 'These can have legitimate causes or be stale. Require seller clearance and online setup verification; offline absence cannot prove Autopilot clearance.'))
    }
    foreach($physical in @(Get-Field $Data 'PhysicalDisks' @())) {
        if ((Get-Field $physical 'HealthStatus') -in 'Unhealthy','Warning') {
            $findings.Add((New-Finding 'Storage' 'warning' 'Windows storage health reports a concern' ((Get-Field $physical 'Model')+': '+(Get-Field $physical 'HealthStatus')) 'Inspect the detailed drive/OEM diagnostics rather than relying on the health label alone.'))
        }
        foreach($counter in 'ReadErrorsUncorrected','WriteErrorsUncorrected') {
            $value=Get-Field $physical $counter
            if ($null -ne $value -and [long]$value -gt 0) {
                $findings.Add((New-Finding 'Storage' 'warning' 'Windows reports uncorrected storage errors' ((Get-Field $physical 'Model')+"; $counter=$value") 'Confirm the counter with the drive/OEM tools. Missing counters are unavailable, not zero.'))
            }
        }
    }
    $coverage = Get-Field $Data 'Coverage'
    $oldest=Get-Field $coverage 'OldestRetainedSystemEvent'
    if ($oldest) {
        try {
            if (((Get-Date)-[datetime]$oldest).TotalDays -lt 7) {
                $findings.Add((New-Finding 'History' 'unknown' 'Only a short System-log history is retained' ([string]$oldest) 'A recent install, log rollover or clearing can hide old faults. Do not treat the lack of historical errors as proof of reliability.'))
            }
        } catch { }
    }
    if ((Get-Field $coverage 'EventLimitReached') -eq $true) {
        $findings.Add((New-Finding 'History' 'unknown' 'Event query reached its record limit' 'Older matching records in the selected period may be omitted.' 'Review the JSON and Windows Event Viewer before treating history as complete.'))
    }
    foreach ($err in @(Get-Field $Data 'CollectionErrors' @())) {
        $findings.Add((New-Finding 'Coverage' 'unknown' ('Could not collect: '+$err.Check) $err.Error 'Unavailable information is not a successful check. Try Administrator access or OEM diagnostics.'))
    }
    $criticalCount = @($findings | Where-Object Severity -eq 'critical').Count
    $warningCount = @($findings | Where-Object Severity -eq 'warning').Count
    $unknownCount = @($findings | Where-Object Severity -eq 'unknown').Count
    $decision = if ($criticalCount -gt 0) {'SERIOUS FINDINGS - RESOLVE BEFORE BUYING'} elseif (@($requirements | Where-Object Status -eq 'BELOW').Count) {'BELOW YOUR SPECIFICATION TARGET'} elseif ($warningCount -gt 0) {'INVESTIGATE BEFORE BUYING'} elseif ($unknownCount -gt 0) {'INCOMPLETE - MORE CHECKS NEEDED'} else {'NO MAJOR AUTOMATED FLAGS - MANUAL CHECKS STILL REQUIRED'}
    [pscustomobject]@{Decision=$decision;Requirements=@($requirements.ToArray());Findings=@($findings.ToArray());Critical=$criticalCount;Warnings=$warningCount;Unknown=$unknownCount}
}

function ConvertTo-SafeHtml {
    param($Value)
    [System.Net.WebUtility]::HtmlEncode([string]$Value)
}
