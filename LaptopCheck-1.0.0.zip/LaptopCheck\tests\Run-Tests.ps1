﻿$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '..\Assessment.ps1')
. (Join-Path $PSScriptRoot '..\Report.ps1')
$passed=0
function Assert-True($Condition,[string]$Message) {
    if(-not $Condition){throw "FAIL: $Message"}
    $script:passed++
    Write-Output "PASS: $Message"
}
function New-Fixture {
    [pscustomobject]@{
        ToolVersion='test';CapturedAt='2026-01-01';Administrator=$true
        Computer=[pscustomobject]@{Manufacturer='HP';Model='Example';DomainJoined=$false}
        Windows=@{};CPU=@{Name='11th Gen Intel(R) Core(TM) i7-1165G7 @ 2.80GHz'}
        Memory=@{InstalledGB=16};OSDisk=@{Model='Example SSD';SizeBytes=512110190592;BusType='NVMe';MediaType='SSD'}
        Batteries=@(@{Name='Battery';DesignMWh=50000;FullMWh=45000;Cycles=100})
        Smart=@(@{Device='/dev/sda';Data=@{model_name='Example SSD';smart_status=@{passed=$true};nvme_smart_health_information_log=@{critical_warning=0;media_errors=0;percentage_used=7;num_err_log_entries=25000;unsafe_shutdowns=10}}})
        DeviceProblems=@();Events=@();MemoryTests=@(@{Completion='Pass';Time='2025-01-01';Message='Passed'})
        Samples=@();ManualChecks=@();Setup=@{};Coverage=@{};CollectionErrors=@();PhysicalDisks=@()
        Disks=@();Graphics=@();Network=@();CrashDumpInventory=@()
    }
}
Assert-True ((Get-IntelGeneration 'Intel Core i7-1165G7') -eq 11) '11th-gen graphics suffix is not mistaken for generation 7'
Assert-True ((Get-IntelGeneration 'Intel Core i7-8650U') -eq 8) '8th-generation mobile CPU identified'
Assert-True ((Get-IntelGeneration 'Intel Core i7-1355U') -eq 13) '13th-generation four-digit mobile model identified'
Assert-True ((Get-IntelGeneration 'Intel Core i7-10510U') -eq 10) '10th-generation five-digit mobile model identified'
Assert-True ($null -eq (Get-IntelGeneration 'Intel Core 7 150U')) 'Core 7 150U is not mislabeled 15th generation'
Assert-True ($null -eq (Get-IntelGeneration 'AMD Ryzen 7 7840U')) 'AMD is not incorrectly converted into Intel generation'
$f=New-Fixture; $a=Get-Assessment $f
Assert-True (@($a.Requirements | Where-Object Status -ne 'MEETS').Count -eq 0) '512GB decimal disk and installed 16GB meet targets'
Assert-True ($a.Critical -eq 0 -and $a.Warnings -eq 0) 'NVMe command-error count alone is not a failure'
$f=New-Fixture;$f.MemoryTests=@();$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object {$_.Area -eq 'Memory' -and $_.Severity -eq 'unknown'}).Count -eq 1) 'Missing RAM test is unknown, not passed'
$f=New-Fixture;$f.Smart=@();$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object {$_.Area -eq 'Storage' -and $_.Severity -eq 'unknown'}).Count -eq 1) 'Missing SMART is unknown, not healthy'
$f=New-Fixture;$f.Smart[0].Data.nvme_smart_health_information_log.media_errors=1;$a=Get-Assessment $f
Assert-True ($a.Critical -eq 1) 'Nonzero media errors are highlighted'
$f=New-Fixture;$f.Batteries[0].FullMWh=22000;$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object {$_.Area -eq 'Battery' -and $_.Severity -eq 'warning'}).Count -eq 1) 'Worn battery flagged'
$f=New-Fixture;$f.Events=@(@{Kind='UnexpectedRestart';Time='2026-01-01'});$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object Area -eq 'Stability')[0].Next -match 'not proof') 'Event 41 does not establish physical power loss'
$f=New-Fixture;$f.CPU.Name='Intel Core i5-1135G7';$a=Get-Assessment $f
Assert-True (@($a.Requirements | Where-Object {$_.Name -eq 'CPU marketing tier' -and $_.Status -eq 'BELOW'}).Count -eq 1) 'i5 does not silently meet the requested i7 tier'
$f=New-Fixture;$f.OSDisk.MediaType='HDD';$f.OSDisk.BusType='SATA';$a=Get-Assessment $f
Assert-True (@($a.Requirements | Where-Object {$_.Name -eq 'Windows drive type' -and $_.Status -eq 'BELOW'}).Count -eq 1) 'Large HDD does not pass the SSD requirement'
$f=New-Fixture;$f.MemoryTests=@(@{Completion='Fail';BadPages=1;Message='Bad memory'});$a=Get-Assessment $f
Assert-True ($a.Critical -eq 1) 'Failed memory test is a serious finding'
$f=New-Fixture;$f.Computer.Model='<script>alert("machine")</script>';$a=Get-Assessment $f;$html=New-InspectionHtml $f $a
Assert-True ($html -notmatch '<script>alert' -and $html -match '&lt;script&gt;') 'Hardware strings are escaped in HTML reports'
$f=New-Fixture;$f.Memory.InstalledGB=$null;$f.OSDisk=$null;$a=Get-Assessment $f
Assert-True (@($a.Requirements | Where-Object Status -eq 'UNKNOWN').Count -ge 3) 'Unavailable hardware data stays unknown'
$f=New-Fixture;$f.Smart=@(@{Data=@{smart_status=@{passed=$true};ata_smart_attributes=@{table=@(@{id=197;name='Current_Pending_Sector';raw=@{value=2}})}}});$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object Title -eq 'ATA media-related attribute needs review').Count -eq 1) 'ATA pending-sector evidence is not ignored'
$f=New-Fixture;$f.Setup=@{HPBiosPasswordIndicators=@(@{Name='Setup password';IsSet=1})};$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object Title -eq 'Firmware password presence reported').Count -eq 1) 'Firmware password presence is flagged'
$f=New-Fixture;$f.PhysicalDisks=@(@{Model='SSD';ReadErrorsUncorrected=3});$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object Title -eq 'Windows reports uncorrected storage errors').Count -eq 1) 'Uncorrected Windows storage counters are not ignored'
$f=New-Fixture;$f.Batteries=@();$f.Computer | Add-Member IsPortable $false;$a=Get-Assessment $f
Assert-True (@($a.Findings | Where-Object {$_.Area -eq 'Battery' -and $_.Severity -eq 'unknown'}).Count -eq 0) 'Desktop battery absence is not treated as a missing laptop check'
$f=New-Fixture;$f.CPU.Name='Intel Core i7-1355U';$a=Get-Assessment $f -MinRamGB 32
Assert-True (@($a.Requirements | Where-Object {$_.Name -eq 'Installed RAM' -and $_.Status -eq 'BELOW'}).Count -eq 1) 'Custom 32GB target is respected'
Write-Output "`n$passed assertions passed."
