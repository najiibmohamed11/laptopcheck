﻿$ErrorActionPreference='Stop'
$releaseRoot=Join-Path $PSScriptRoot 'dist'
$stage=Join-Path $releaseRoot ('LaptopCheck-1.0.0-'+[guid]::NewGuid().ToString('N').Substring(0,6))
$payload=Join-Path $stage 'LaptopCheck'
[void](New-Item -ItemType Directory -Path $payload -Force)
# Explicit allowlist: never ship this computer's reports or test output.
$files=@('LaptopCheck.ps1','Assessment.ps1','Report.ps1','Check-Laptop.cmd','Inspect-This-Laptop.cmd','README.md','START-HERE.txt','LICENSE.txt','THIRD-PARTY.txt','Build-Package.ps1')
foreach($file in $files){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination $payload}
[void](New-Item -ItemType Directory -Path (Join-Path $payload 'tests') -Force)
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'tests\Run-Tests.ps1') -Destination (Join-Path $payload 'tests')
[void](New-Item -ItemType Directory -Path (Join-Path $payload 'third-party') -Force)
foreach($file in 'smartctl.exe','SMARTMONTOOLS-COPYING.txt','smartmontools-7.5.tar.gz') {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('third-party\'+$file)) -Destination (Join-Path $payload 'third-party')
}
$utf8Bom=New-Object System.Text.UTF8Encoding($true)
Get-ChildItem -LiteralPath $payload -Recurse -Filter *.ps1 | ForEach-Object {
    $source=[IO.File]::ReadAllText($_.FullName)
    [IO.File]::WriteAllText($_.FullName,$source,$utf8Bom)
}
$manifest=Get-ChildItem -LiteralPath $payload -Recurse -File | ForEach-Object {
    [pscustomobject]@{Path=$_.FullName.Substring($payload.Length+1);SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
}
$manifest | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $payload 'SHA256SUMS.json') -Encoding UTF8
$zipPath=Join-Path $releaseRoot 'LaptopCheck-1.0.0.zip'
Compress-Archive -LiteralPath $payload -DestinationPath $zipPath -Force
Write-Output $zipPath
