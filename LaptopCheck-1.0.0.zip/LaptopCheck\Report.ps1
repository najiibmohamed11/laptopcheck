﻿function New-InspectionHtml {
    param($Data, $Assessment)
    $sb=New-Object System.Text.StringBuilder
    [void]$sb.Append(@'
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Laptop inspection</title><style>
:root{color-scheme:light;--ink:#142133;--muted:#506073;--line:#dce3eb;--card:#f3f6fa}*{box-sizing:border-box}body{font:15px/1.5 system-ui,sans-serif;color:var(--ink);margin:0 auto;padding:24px;max-width:1080px;background:white}h1{font-size:26px;margin-bottom:4px}h2{font-size:20px;margin-top:30px}.muted{color:var(--muted)}.verdict{background:#e9eff8;padding:16px;border-radius:10px;font-weight:700}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:20px 0}.card{padding:14px;background:var(--card);border-radius:9px}.card small{display:block;color:var(--muted)}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;vertical-align:top;border-bottom:1px solid var(--line);padding:10px 8px;overflow-wrap:anywhere}th{background:var(--card)}.finding{border:1px solid var(--line);border-left:5px solid #5b6b7d;border-radius:7px;padding:12px 16px;margin:10px 0}.finding.critical{border-left-color:#b42318;background:#fff4f2}.finding.warning{border-left-color:#a56700;background:#fffaf0}.finding.unknown{border-left-color:#6351a5}.finding h3{font-size:15px;margin:0 0 6px}.finding p{margin:4px 0}.badge{font-size:11px;letter-spacing:.04em;font-weight:700}.manual li{margin:9px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;background:var(--card);padding:14px;border-radius:8px}summary{cursor:pointer;font-weight:600}details{margin:14px 0}.scroll{overflow-x:auto}@media print{body{max-width:none;padding:0}.finding{break-inside:avoid}details pre{font-size:10px}}@media(max-width:550px){body{padding:14px}th,td{padding:8px 4px;font-size:12px}}
</style></head><body><h1>Used-laptop inspection</h1>
'@)
    [void]$sb.Append('<p class="muted">Captured '+(ConvertTo-SafeHtml $Data.CapturedAt)+' · Tool '+(ConvertTo-SafeHtml $Data.ToolVersion)+' · Administrator: '+(ConvertTo-SafeHtml $Data.Administrator)+'</p>')
    [void]$sb.Append('<div class="verdict">'+(ConvertTo-SafeHtml $Assessment.Decision)+'</div>')
    [void]$sb.Append('<div class="cards">')
    $cards=@(
        @('Machine',($Data.Computer.Manufacturer+' '+$Data.Computer.Model)),
        @('Processor',$Data.CPU.Name),
        @('Memory',([string]$Data.Memory.InstalledGB+' GiB')),
        @('Windows disk',([string](Get-Field $Data.OSDisk 'Model' 'UNKNOWN')))
    )
    foreach($c in $cards){[void]$sb.Append('<div class="card"><small>'+(ConvertTo-SafeHtml $c[0])+'</small>'+(ConvertTo-SafeHtml $c[1])+'</div>')}
    [void]$sb.Append('</div><p><strong>'+$Assessment.Critical+' serious findings · '+$Assessment.Warnings+' warnings · '+$Assessment.Unknown+' unknowns.</strong> This is a snapshot, not a health certificate. Physical condition, BIOS access, charger suitability and online enrollment checks remain necessary.</p>')
    [void]$sb.Append('<h2>Your specification targets</h2><div class="scroll"><table><thead><tr><th>Check</th><th>Result</th><th>Observed</th><th>Target</th></tr></thead><tbody>')
    foreach($r in $Assessment.Requirements){[void]$sb.Append('<tr><td>'+(ConvertTo-SafeHtml $r.Name)+'</td><td><strong>'+(ConvertTo-SafeHtml $r.Status)+'</strong></td><td>'+(ConvertTo-SafeHtml $r.Actual)+'</td><td>'+(ConvertTo-SafeHtml $r.Target)+'</td></tr>')}
    [void]$sb.Append('</tbody></table></div><p class="muted">CPU tier is a marketing category, not a cross-generation performance ranking. Modern Intel Core/Core Ultra and AMD names require manual comparison. Disk capacity uses decimal GB; Windows usually displays GiB.</p><h2>Findings and evidence</h2>')
    foreach($severity in 'critical','warning','unknown','note') {
        foreach($f in @($Assessment.Findings | Where-Object Severity -eq $severity)) {
            [void]$sb.Append('<section class="finding '+$severity+'"><span class="badge">'+$severity.ToUpperInvariant()+' · '+(ConvertTo-SafeHtml $f.Area)+'</span><h3>'+(ConvertTo-SafeHtml $f.Title)+'</h3><p>'+(ConvertTo-SafeHtml $f.Evidence)+'</p><p><strong>Next:</strong> '+(ConvertTo-SafeHtml $f.Next)+'</p></section>')
        }
    }
    [void]$sb.Append('<h2>Physical and seller checks</h2><ul class="manual">')
    foreach($m in $Data.ManualChecks){[void]$sb.Append('<li><strong>['+(ConvertTo-SafeHtml $m.Result)+']</strong> '+(ConvertTo-SafeHtml $m.Name)+'</li>')}
    [void]$sb.Append('</ul><p class="muted">Use -Interactive when running the CLI to record your answers. No browser is needed to collect hardware data; this HTML is an offline report.</p><h2>Evidence details</h2>')
    $sections=@(
        @('System, BIOS and Windows',[pscustomobject]@{Computer=$Data.Computer;Windows=$Data.Windows;CPU=$Data.CPU}),
        @('RAM modules and firmware-reported slot data',$Data.Memory),
        @('Disks and Windows counters',[pscustomobject]@{OSDisk=$Data.OSDisk;Disks=$Data.Disks;PhysicalDisks=$Data.PhysicalDisks}),
        @('Battery capacity records',$Data.Batteries),
        @('SMART health payloads',$Data.Smart),
        @('Idle power and ACPI thermal samples',$Data.Samples),
        @('Device problems, graphics and network',[pscustomobject]@{Problems=$Data.DeviceProblems;Graphics=$Data.Graphics;Network=$Data.Network}),
        @('Shutdown/storage/hardware events',$Data.Events),
        @('Saved memory tests and dump names',[pscustomobject]@{MemoryTests=$Data.MemoryTests;Dumps=$Data.CrashDumpInventory}),
        @('Secure Boot, TPM and management indicators',$Data.Setup),
        @('Coverage and collection errors',[pscustomobject]@{Coverage=$Data.Coverage;Errors=$Data.CollectionErrors})
    )
    foreach($section in $sections) {
        $value=ConvertTo-Json -InputObject $section[1] -Depth 30
        [void]$sb.Append('<details><summary>'+(ConvertTo-SafeHtml $section[0])+'</summary><pre>'+(ConvertTo-SafeHtml $value)+'</pre></details>')
    }
    [void]$sb.Append('<h2>Limits that matter</h2><p>Reinstalling Windows or clearing/rolling over logs can hide old problems. No retained crash history is not proof of reliability. SMART can pass despite intermittent storage-controller faults. SSD power-on hours and battery cycles describe those components, not the complete laptop lifetime. Firmware-reported memory slots may describe soldered chips. ACPI zones may be stale and are not independent per-core CPU measurements. This tool does not analyze dump contents, run a new memory test, test mains wiring or verify that a machine is free of organizational enrollment.</p><p>No repair, installation, reboot, stress test or network request was performed. Reports are written locally. Serials are masked unless explicitly enabled; event messages and hardware IDs may still identify the machine. Review reports before sharing.</p></body></html>')
    $sb.ToString()
}
