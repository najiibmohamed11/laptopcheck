# Laptop Check

A portable, offline Windows inspection tool for buying a used laptop. It collects evidence and produces an HTML report, a plain-text summary and a JSON record. No Python, Node.js, installation or internet connection is required on the inspected computer.

## Take it to the shop

1. Extract the complete ZIP to a USB drive. Keep the scripts and `third-party` folder together.
2. Ask the seller to allow an inspection of the actual machine being sold.
3. Right-click **Inspect-This-Laptop.cmd** and choose **Run as administrator** for the fullest coverage. It also runs without Administrator access and labels unavailable checks.
4. Open the generated `Reports/inspection-.../inspection.html` or `READ-ME-FIRST.txt`. The terminal prints their full paths. Each run gets a separate folder.

If a downloaded ZIP is marked as coming from the internet, Windows may block unsigned PowerShell scripts. Before extracting, right-click the ZIP, choose Properties, and select Unblock if available. The launcher uses a process-scoped RemoteSigned policy; it does not change machine-wide policy or override organization-managed policy.

The normal inspection takes roughly a minute or two, depending on the machine and log size. A short idle sample is included. Unresponsive providers or drives can take longer; individual external commands have timeouts.

## Commands

From a terminal in this folder:

```powershell
.\Check-Laptop.cmd
.\Check-Laptop.cmd -Interactive
.\Check-Laptop.cmd -MinRamGB 32
.\Check-Laptop.cmd -MinIntelTier 5 -MinIntelGeneration 12
.\Check-Laptop.cmd -OutputDirectory "E:\Shop Reports"
.\Check-Laptop.cmd -SampleSeconds 0 -NoSmart
.\Check-Laptop.cmd -IncludeSerialNumbers
.\Check-Laptop.cmd -Help
```

Defaults match the requested buying target: **Core i7, Intel generation 11+, 16GB RAM, 500GB decimal SSD**. A nominal 512GB SSD is about 477GiB in Windows and correctly meets this target. The Windows physical disk is checked, not the USB drive carrying the tool. Current Intel Core/Core Ultra and AMD processors are reported with their exact names and left for manual CPU comparison rather than assigning a misleading Intel generation.

Use `-Interactive` to record pass/fail/unknown answers for the physical and seller checks. This is an inspection record, not an automatic test of a keyboard, hinge or charger.

## What it collects

- Manufacturer/model, BIOS version/date, exact CPU, cores/threads.
- Installed RAM, module details and firmware-reported memory-slot data. **Those slots do not prove RAM is removable.**
- Windows disk capacity/interface/media type, other disks and available reliability counters.
- Battery design/full-charge capacity, estimated wear and cycles; current idle AC/charging readings.
- Detailed supported SMART/NVMe data through bundled smartctl. Known USB report drives are excluded from direct reads. Some RAID/USB bridges cannot expose useful data.
- Present Device Manager error codes, graphics/display and physical network adapter information.
- Retained shutdown/crash, storage, thermal, firmware-throttling and WHEA events. Default lookback is 365 days, with a 2,000-record matching-event cap. Limited history is disclosed.
- Saved Windows Memory Diagnostic results and dump-file inventory. **It does not run a new RAM test or analyze dump contents.**
- Available TPM/Secure Boot, HP BIOS-password-presence and current management-enrollment indicators. **It cannot establish that a machine is free of Autopilot/organizational enrollment.**

## How to interpret the report

The tool never issues an unconditional BUY verdict. Serious findings need resolution; warnings need investigation; UNKNOWN means a check was not established. Specification mismatches are separate from hardware faults. A worn battery can justify a replacement allowance rather than rejection of the entire laptop.

In particular:

- Event 41/6008 does not prove a faulty motherboard or charger, and multiple records can describe one incident.
- NVMe command-error counts can include unsupported monitoring queries. They are not treated as damaged-media counts.
- A SMART pass or Windows Healthy label cannot rule out intermittent drive/controller problems.
- A saved RAM-test pass is historical evidence; no result is not a pass.
- A fresh Windows installation or cleared logs can hide faults.
- ACPI temperatures may be stale and are not independent per-core CPU measurements.
- SSD hours and battery cycles describe those components, not the laptop's complete lifetime.

## What still needs your hands and eyes

Check swelling, hinges, screen/touch, every keyboard key, touchpad, all ports, camera/audio, Wi-Fi, correct charger and unplugged operation. Try a normal cold start, restart and sleep/wake with permission. Ask the seller to demonstrate BIOS access and removal of unknown passwords. Require legitimate removal of company management, then an internet-connected reset/setup check before payment. Get return and warranty coverage in writing, including battery/SSD exclusions.

With seller permission, use the manufacturer's preboot memory and short storage diagnostics. This tool deliberately does not schedule them, restart the PC or start a load/stress benchmark.

## Privacy and machine changes

The inspection writes only its report files. It does not install drivers, repair Windows, change power settings, enable SMART, flash firmware, restart, create startup tasks or send data over the network. SMART reads can be unsupported on some devices; use `-NoSmart` if direct drive queries are unsuitable.

Full BIOS/RAM/disk/battery serials are masked unless `-IncludeSerialNumbers` is supplied. The battery XML also removes computer name and report GUID by default. Hardware IDs, timestamps and event messages can still identify the machine. Review reports before sharing. Dump contents and personal documents are not copied.

The tool runs only on Windows. With Windows absent/locked or hardware that will not power on, use seller-assisted BIOS/UEFI diagnostics instead. It cannot measure startup voltage sag, physically isolate a battery/charger, or verify wall power.

## Development checks

```powershell
powershell -NoProfile -ExecutionPolicy RemoteSigned -File .\tests\Run-Tests.ps1
```

Our scripts are MIT-licensed; see LICENSE.txt. The bundled smartmontools binary has its own GPL license, matching source archive and build instructions in third-party; see THIRD-PARTY.txt.
