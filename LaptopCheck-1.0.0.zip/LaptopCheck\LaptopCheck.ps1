﻿<#
.SYNOPSIS
Offline, read-only Windows used-laptop inspection. Writes reports only.
.EXAMPLE
.\LaptopCheck.ps1 -Interactive -MinRamGB 32
#>
[CmdletBinding()]
param(
    [string]$OutputDirectory,
    [ValidateRange(1,256)][int]$MinRamGB = 16,
    [ValidateRange(1,16000)][int]$MinDiskGB = 500,
    [ValidateRange(1,30)][int]$MinIntelGeneration = 11,
    [ValidateSet(3,5,7,9)][int]$MinIntelTier = 7,
    [ValidateRange(1,3650)][int]$HistoryDays = 365,
    [ValidateRange(100,10000)][int]$MaxEvents = 2000,
    [ValidateRange(0,120)][int]$SampleSeconds = 20,
    [string]$SmartctlPath,
    [switch]$NoSmart,
    [switch]$IncludeSerialNumbers,
    [switch]$Interactive,
    [switch]$Help
)
$ErrorActionPreference = 'Stop'
if ($Help) {
    Write-Output @'
LAPTOP CHECK - portable Windows inspection

  Check-Laptop.cmd                         Standard read-only inspection
  Check-Laptop.cmd -Interactive            Add physical inspection answers
  Check-Laptop.cmd -MinRamGB 32             Target 32GB RAM
  Check-Laptop.cmd -MinIntelTier 5          Allow Core i5 rather than i7
  Check-Laptop.cmd -SampleSeconds 0         Skip the short idle power sample
  Check-Laptop.cmd -OutputDirectory E:\Reports
  Check-Laptop.cmd -IncludeSerialNumbers   Include full hardware identifiers
  Check-Laptop.cmd -NoSmart                Skip direct SMART queries

Defaults: Core i7, Intel generation 11+, 16GB RAM, 500GB decimal SSD.
Modern Core/Core Ultra/Ryzen names require manual comparison.
Use Administrator access for best coverage. Standard-user partial reports work.
No installations, settings changes, downloads, repairs, restarts or stress tests.
This tool writes reports only. Ask the seller before inspecting their machine.
'@
    exit 0
}
if ($env:OS -ne 'Windows_NT') { throw 'This tool requires Windows PowerShell 5.1 or PowerShell on Windows.' }
if (-not $OutputDirectory) { $OutputDirectory=Join-Path $PSScriptRoot 'Reports' }
. (Join-Path $PSScriptRoot 'Assessment.ps1')
$collectionErrors = New-Object 'System.Collections.Generic.List[object]'
function Read-Check {
    param([string]$Name, [scriptblock]$Action, [switch]$AllowNoMatches)
    try { & $Action } catch {
        if ($AllowNoMatches -and $_.FullyQualifiedErrorId -like 'NoMatchingEventsFound*') { return }
        $collectionErrors.Add([pscustomobject]@{Check=$Name;Error=$_.Exception.Message})
        Write-Host "  Unavailable: $Name" -ForegroundColor Yellow
    }
}
function Protect-Identifier {
    param($Value)
    if ($null -eq $Value) { return $null }
    $s = ([string]$Value).Trim()
    if ($IncludeSerialNumbers -or $s.Length -eq 0) { return $s }
    if ($s.Length -le 4) { return '[masked]' }
    return ('***' + $s.Substring($s.Length-4))
}
function Invoke-ReadProgram {
    param([string]$Program, [string[]]$Arguments, [int]$TimeoutSeconds=25)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Program
    # No shell is involved. Escape quotes/backslashes using Windows argv rules.
    $quoted = foreach ($a in $Arguments) {
        '"' + ([regex]::Replace([regex]::Replace($a, '(\\*)"', '$1$1\"'), '(\\+)$', '$1$1')) + '"'
    }
    $psi.Arguments = $quoted -join ' '
    $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true
    $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo=$psi
    try {
        [void]$p.Start()
        $stdout=$p.StandardOutput.ReadToEndAsync(); $stderr=$p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($TimeoutSeconds*1000)) {
            $p.Kill(); $p.WaitForExit()
            throw "Read-only command timed out after $TimeoutSeconds seconds."
        }
        [pscustomobject]@{ExitCode=$p.ExitCode;Out=$stdout.Result;Error=$stderr.Result}
    } finally { $p.Dispose() }
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$runTime=Get-Date
$runName='inspection-'+$runTime.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,6)
$reportDirectory=Join-Path $OutputDirectory $runName
[void](New-Item -ItemType Directory -Path $reportDirectory -Force)
$reportDirectory=(Resolve-Path -LiteralPath $reportDirectory).Path
Write-Host "`nLAPTOP CHECK - offline buying inspection" -ForegroundColor Cyan
Write-Host "Reports: $reportDirectory"
if (-not $isAdmin) { Write-Host 'Standard-user mode: some logs, counters and SMART reads may be unavailable.' -ForegroundColor Yellow }
Write-Host '[1/7] Identity, processor, RAM and storage'
$cs=@(Read-Check 'Computer identity' { Get-CimInstance Win32_ComputerSystem -OperationTimeoutSec 10 }) | Select-Object -First 1
$bios=@(Read-Check 'BIOS' { Get-CimInstance Win32_BIOS -OperationTimeoutSec 10 }) | Select-Object -First 1
$os=@(Read-Check 'Windows' { Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10 }) | Select-Object -First 1
$cpu=@(Read-Check 'CPU' { Get-CimInstance Win32_Processor -OperationTimeoutSec 10 }) | Select-Object -First 1
$ramModules=@(Read-Check 'RAM modules' { Get-CimInstance Win32_PhysicalMemory -OperationTimeoutSec 10 } | ForEach-Object {
    [pscustomobject]@{Manufacturer=$_.Manufacturer;PartNumber=([string]$_.PartNumber).Trim();CapacityGiB=[math]::Round($_.Capacity/1GB,2);SpeedMTs=$_.ConfiguredClockSpeed;Locator=$_.DeviceLocator;Serial=(Protect-Identifier $_.SerialNumber)}
})
$ramArrays=@(Read-Check 'Firmware RAM slot count' { Get-CimInstance Win32_PhysicalMemoryArray -OperationTimeoutSec 10 } | Select-Object MemoryDevices,MaxCapacity,MaxCapacityEx)
$installedGB=$null
if ($null -ne $cs -and $cs.TotalPhysicalMemory) { $installedGB=[math]::Round($cs.TotalPhysicalMemory/1GB,1) }
if ($ramModules.Count) { $installedGB=[math]::Round(($ramModules | Measure-Object CapacityGiB -Sum).Sum,1) }
$disks=@(Read-Check 'Windows storage devices' { Get-Disk | Sort-Object Number } | ForEach-Object {
    [pscustomobject]@{Number=$_.Number;Model=$_.FriendlyName;SizeBytes=$_.Size;BusType=[string]$_.BusType;HealthStatus=[string]$_.HealthStatus;OperationalStatus=([string]$_.OperationalStatus);Serial=(Protect-Identifier $_.SerialNumber)}
})
$physicalDisks=@(Read-Check 'Physical disk counters' { Get-PhysicalDisk } | ForEach-Object {
    $pd=$_
    $reliability=@(Read-Check ('Reliability counters: '+$pd.FriendlyName) { $pd | Get-StorageReliabilityCounter }) | Select-Object -First 1
    [pscustomobject]@{DeviceId=$pd.DeviceId;Model=$pd.FriendlyName;MediaType=[string]$pd.MediaType;BusType=[string]$pd.BusType;SizeBytes=$pd.Size;HealthStatus=[string]$pd.HealthStatus;Temperature=(Get-Field $reliability 'Temperature');TemperatureMax=(Get-Field $reliability 'TemperatureMax');Wear=(Get-Field $reliability 'Wear');PowerOnHours=(Get-Field $reliability 'PowerOnHours');ReadErrorsUncorrected=(Get-Field $reliability 'ReadErrorsUncorrected');WriteErrorsUncorrected=(Get-Field $reliability 'WriteErrorsUncorrected')}
})
$osDisk=$null
if ($null -ne $os) {
    $part=@(Read-Check 'Windows disk mapping' { Get-Partition -DriveLetter $os.SystemDrive.TrimEnd(':') }) | Select-Object -First 1
    if ($null -ne $part) {
        $mapped=@($disks | Where-Object Number -eq $part.DiskNumber) | Select-Object -First 1
        if ($null -ne $mapped) {
            $media=@($physicalDisks | Where-Object { [string]$_.DeviceId -eq [string]$mapped.Number -and $_.Model -eq $mapped.Model }) | Select-Object -First 1
            $osDisk=[pscustomobject]@{Number=$mapped.Number;Model=$mapped.Model;SizeBytes=$mapped.SizeBytes;BusType=$mapped.BusType;MediaType=(Get-Field $media 'MediaType');Serial=$mapped.Serial}
        }
    }
}
$video=@(Read-Check 'Graphics/display' { Get-CimInstance Win32_VideoController -OperationTimeoutSec 10 } | Select-Object Name,DriverVersion,CurrentHorizontalResolution,CurrentVerticalResolution)
$adapters=@(Read-Check 'Network adapters' { Get-NetAdapter -Physical } | Select-Object Name,InterfaceDescription,Status,LinkSpeed)

Write-Host '[2/7] Battery capacity report'
$batteries=@()
$batteryXmlPath=Join-Path $reportDirectory 'battery-report.xml'
if ($null -ne (Get-Command powercfg.exe -ErrorAction SilentlyContinue)) {
    $batteryResult=Read-Check 'Battery report' { Invoke-ReadProgram (Join-Path $env:WINDIR 'System32\powercfg.exe') @('/batteryreport','/xml','/output',$batteryXmlPath) }
    if (Test-Path -LiteralPath $batteryXmlPath) {
        $batteryXml=New-Object System.Xml.XmlDocument
        $batteryXml.XmlResolver=$null
        $batteryXml.Load($batteryXmlPath)
        $batteries=@($batteryXml.SelectNodes("//*[local-name()='Batteries']/*[local-name()='Battery']") | ForEach-Object {
            [pscustomobject]@{Name=[string]$_.Id;DesignMWh=$(if($_.DesignCapacity){[double]$_.DesignCapacity}else{$null});FullMWh=$(if($_.FullChargeCapacity){[double]$_.FullChargeCapacity}else{$null});Cycles=$(if([string]$_.CycleCount -ne ''){[int]$_.CycleCount}else{$null});Manufacturer=[string]$_.Manufacturer;Serial=(Protect-Identifier $_.SerialNumber)}
        })
        if (-not $IncludeSerialNumbers) {
            foreach($node in $batteryXml.SelectNodes("//*[local-name()='SerialNumber' or local-name()='ComputerName' or local-name()='ReportGuid']")) { $node.InnerText='[redacted]' }
            $batteryXml.Save($batteryXmlPath)
        }
    } elseif ($null -ne $batteryResult -and $batteryResult.ExitCode -ne 0) {
        # Lack of a battery is normal on desktops; report it explicitly, without fabricating health.
        Write-Host '  No battery report produced (desktop/no supported battery, or unavailable).'
    }
}

Write-Host '[3/7] Device errors, firmware and setup indicators'
$problemDevices=@(Read-Check 'Present device problem codes' { Get-CimInstance Win32_PnPEntity -Filter 'ConfigManagerErrorCode <> 0' -OperationTimeoutSec 10 } | Where-Object { $_.Present -ne $false } | ForEach-Object {
    [pscustomobject]@{Name=$_.Name;Code=$_.ConfigManagerErrorCode;HardwareIds=@($_.HardwareID)}
})
$secureBoot=Read-Check 'Secure Boot state' { Confirm-SecureBootUEFI }
$tpm=Read-Check 'TPM state' { Get-Tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,TpmActivated }
$biosPasswords=@()
if ([string](Get-Field $cs 'Manufacturer') -match '(?i)HP|Hewlett') {
    # Query only password-presence metadata. No passwords are read or set.
    $biosPasswords=@(Read-Check 'HP BIOS password indicators' { Get-CimInstance -Namespace root/HP/InstrumentedBIOS -ClassName HP_BIOSPassword -OperationTimeoutSec 8 } | Select-Object Name,IsSet)
}
$mdmCount=Read-Check 'Current enrollment indicators' {
    $count=0
    if (Test-Path HKLM:\SOFTWARE\Microsoft\Enrollments) {
        foreach($key in Get-ChildItem HKLM:\SOFTWARE\Microsoft\Enrollments) {
            $p=Get-ItemProperty -LiteralPath $key.PSPath -Name EnrollmentState -ErrorAction SilentlyContinue
            if ($null -ne $p -and $p.EnrollmentState -eq 1) { $count++ }
        }
    }
    $count
}

Write-Host '[4/7] Retained shutdown, storage, hardware and memory-test events'
$since=$runTime.AddDays(-$HistoryDays)
$earliest=Read-Check 'Oldest retained System event' { (Get-WinEvent -LogName System -Oldest -MaxEvents 1).TimeCreated.ToString('o') }
$ids=41,6008,1001,129,153,7,51,55,98,37,86,88,524,104
$rawEvents=@(Read-Check 'System error history' { Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$since;Id=$ids} -MaxEvents $MaxEvents -ErrorAction Stop } -AllowNoMatches)
$events=@(foreach($ev in $rawEvents) {
    $kind=$null
    if ($ev.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $ev.Id -eq 41) { $kind='UnexpectedRestart' }
    elseif ($ev.ProviderName -eq 'EventLog' -and $ev.Id -eq 6008) { $kind='UnexpectedRestart' }
    elseif ($ev.ProviderName -eq 'Microsoft-Windows-WER-SystemErrorReporting' -and $ev.Id -eq 1001) { $kind='Bugcheck' }
    elseif ($ev.ProviderName -match '^(stornvme|storahci|disk|Microsoft-Windows-Ntfs|Ntfs)$' -and $ev.Id -in 129,153,7,51,55,98 -and $ev.Level -le 3) { $kind='Storage' }
    elseif ($ev.ProviderName -eq 'Microsoft-Windows-Kernel-Processor-Power' -and $ev.Id -eq 37) { $kind='FirmwareLimit' }
    elseif ($ev.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $ev.Id -eq 524) { $kind='CriticalBattery' }
    elseif ($ev.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $ev.Id -in 86,88) { $kind='Thermal' }
    elseif ($ev.ProviderName -eq 'Microsoft-Windows-Eventlog' -and $ev.Id -eq 104) { $kind='LogCleared' }
    if ($null -ne $kind) {
        $code=$null; $longPress=$null
        if ($ev.Id -eq 41 -and $kind -eq 'UnexpectedRestart') {
            [xml]$xml=$ev.ToXml()
            foreach($v in $xml.Event.EventData.Data) {
                if ($v.Name -eq 'BugcheckCode') { $code='0x{0:X}' -f [long]$v.'#text' }
                if ($v.Name -eq 'LongPowerButtonPressDetected') { $longPress=[string]$v.'#text' }
            }
            if ($null -ne $code -and $code -ne '0x0') { $kind='Bugcheck' }
        }
        [pscustomobject]@{Time=$ev.TimeCreated.ToString('o');Kind=$kind;Provider=$ev.ProviderName;Id=$ev.Id;Bugcheck=$code;LongPowerPress=$longPress;Message=$ev.Message}
    }
})
$whea=@(Read-Check 'WHEA history' { Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-WHEA-Logger';StartTime=$since} -MaxEvents 100 -ErrorAction Stop } -AllowNoMatches)
$events+=@($whea | ForEach-Object {[pscustomobject]@{Time=$_.TimeCreated.ToString('o');Kind='HardwareError';Provider=$_.ProviderName;Id=$_.Id;Bugcheck=$null;LongPowerPress=$null;Message=$_.Message}})
$memoryEvents=@(Read-Check 'Saved memory diagnostics' { Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-MemoryDiagnostics-Results';Id=1101,1102,1201,1202} -MaxEvents 8 -ErrorAction Stop } -AllowNoMatches)
$memoryTests=@($memoryEvents | ForEach-Object {
    $testXml=New-Object System.Xml.XmlDocument; $testXml.XmlResolver=$null; $testXml.LoadXml($_.ToXml())
    $completion=$testXml.SelectSingleNode("//*[local-name()='CompletionType']")
    $bad=$testXml.SelectSingleNode("//*[local-name()='NumBadPages']")
    [pscustomobject]@{Time=$_.TimeCreated.ToString('o');Id=$_.Id;Completion=$(if($completion){$completion.InnerText}else{$null});BadPages=$(if($bad){[long]$bad.InnerText}else{$null});Message=$_.Message}
})
$dumps=@(Read-Check 'Crash dump inventory (names only)' {
    foreach($folder in @((Join-Path $env:WINDIR 'Minidump'),(Join-Path $env:WINDIR 'LiveKernelReports'))) {
        if (Test-Path -LiteralPath $folder) { Get-ChildItem -LiteralPath $folder -Filter *.dmp -Recurse -ErrorAction Stop | Select-Object Name,Length,LastWriteTime }
    }
})

Write-Host '[5/7] Read-only SMART health (no self-tests)'
$smart=@()
if (-not $NoSmart) {
    if (-not $SmartctlPath) {
        $candidates=@((Join-Path $PSScriptRoot 'third-party\smartctl.exe'),(Join-Path $env:ProgramFiles 'smartmontools\bin\smartctl.exe'))
        $SmartctlPath=@($candidates | Where-Object {Test-Path -LiteralPath $_}) | Select-Object -First 1
    }
    if ($SmartctlPath) {
        $SmartctlPath=(Resolve-Path -LiteralPath $SmartctlPath).Path
        $scan=Read-Check 'SMART device enumeration' { Invoke-ReadProgram $SmartctlPath @('--scan','-j') }
        if ($null -ne $scan) {
            $scanJson=Read-Check 'SMART enumeration JSON' { $scan.Out | ConvertFrom-Json }
            $smartList=New-Object 'System.Collections.Generic.List[object]'
            foreach($dev in @(Get-Field $scanJson 'devices' @())) {
                # Match Windows /dev/sdX ordering only to exclude known USB report drives.
                $device=[string]$dev.name; $type=[string]$dev.type
                if ($device -notmatch '^/dev/(sd[a-z]+|pd\d+|nvme\d+)$' -or $type -notmatch '^(nvme|ata|sat|scsi)$') { continue }
                $knownUsb=$false
                if ($device -match '^/dev/sd([a-z])$') {
                    $number=[int][char]$Matches[1]-[int][char]'a'
                    $knownUsb=@($disks | Where-Object { $_.Number -eq $number -and $_.BusType -eq 'USB' }).Count -gt 0
                }
                if ($knownUsb) { continue }
                $argsList=@('-j','-a','-d',$type)
                if (-not $IncludeSerialNumbers) { $argsList+=@('-q','noserial') }
                $argsList+=$device
                $response=Read-Check ('SMART read: '+$device) { Invoke-ReadProgram $SmartctlPath $argsList }
                if ($null -ne $response) {
                    $j=Read-Check ('SMART JSON: '+$device) {$response.Out | ConvertFrom-Json}
                    if ($null -ne $j) {
                        $smartList.Add([pscustomobject]@{Device=$device;Type=$type;ExitCode=$response.ExitCode;Data=$j})
                        $safeName=$device -replace '[^a-zA-Z0-9]','-'
                        $j | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $reportDirectory ('smart'+$safeName+'.json')) -Encoding UTF8
                    }
                }
            }
            $smart=@($smartList.ToArray())
        }
    } else { Write-Host '  smartctl not found. Detailed SMART remains UNKNOWN.' -ForegroundColor Yellow }
}

Write-Host "[6/7] Idle battery/power sample ($SampleSeconds seconds; no artificial load)"
$samples=New-Object 'System.Collections.Generic.List[object]'
$sampleCount=if($SampleSeconds -eq 0){0}else{[int][math]::Ceiling($SampleSeconds/5.0)+1}
for($i=0;$i -lt $sampleCount;$i++) {
    $b=@(Read-Check 'Current battery telemetry' {Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus -OperationTimeoutSec 8}) | Select-Object -First 1
    $zones=@(Read-Check 'ACPI thermal-zone telemetry' {Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -OperationTimeoutSec 8} | ForEach-Object {
        [pscustomobject]@{Zone=$_.InstanceName;Celsius=[math]::Round(($_.CurrentTemperature-2732)/10.0,1)}
    })
    $samples.Add([pscustomobject]@{Time=(Get-Date).ToString('o');AC=$b.PowerOnline;Charging=$b.Charging;Discharging=$b.Discharging;RemainingMWh=$b.RemainingCapacity;ChargeMW=$b.ChargeRate;DischargeMW=$b.DischargeRate;VoltageMV=$b.Voltage;ThermalZones=$zones})
    if ($null -eq $b) { break }
    if ($i -lt $sampleCount-1) { Start-Sleep -Seconds 5 }
}

Write-Host '[7/7] Physical inspection checklist and reports'
$manualNames=@('No swelling, liquid damage or cracked/loose hinges','Screen and touch/pen function checked (if fitted)','Every keyboard key and touchpad checked','USB, charging, audio, webcam, speakers and network checked','Correct charger wattage and stable charging checked','Unplugged operation and battery percentage behavior checked','Cold boot, restart, sleep/wake and BIOS stability checked','No unknown BIOS/admin password; ownership/management cleared','Seller reset/setup with internet checked for company enrollment','Written return terms and battery/SSD warranty coverage obtained')
$manualChecks=@(foreach($name in $manualNames) {
    $answer='NOT CHECKED'
    if ($Interactive) {
        do { $reply=(Read-Host "$name [p=pass / f=fail / u=unknown]").Trim().ToLowerInvariant() } while ($reply -notin 'p','f','u','')
        $answer=switch($reply){'p'{'PASS'} 'f'{'FAIL'} default{'NOT CHECKED'}}
    }
    [pscustomobject]@{Name=$name;Result=$answer}
})
$data=[pscustomobject]@{
    ToolVersion='1.0.0';CapturedAt=$runTime.ToString('o');Administrator=$isAdmin
    Computer=[pscustomobject]@{Manufacturer=(Get-Field $cs 'Manufacturer');Model=(Get-Field $cs 'Model');IsPortable=((Get-Field $cs 'PCSystemType') -eq 2);DomainJoined=(Get-Field $cs 'PartOfDomain');BIOS=(Get-Field $bios 'SMBIOSBIOSVersion');BIOSDate=(Get-Field $bios 'ReleaseDate');Serial=(Protect-Identifier (Get-Field $bios 'SerialNumber'))}
    Windows=[pscustomobject]@{Caption=(Get-Field $os 'Caption');Version=(Get-Field $os 'Version');Build=(Get-Field $os 'BuildNumber');CurrentOSInstallDate=(Get-Field $os 'InstallDate');LastBoot=(Get-Field $os 'LastBootUpTime')}
    CPU=[pscustomobject]@{Name=(Get-Field $cpu 'Name');Cores=(Get-Field $cpu 'NumberOfCores');Threads=(Get-Field $cpu 'NumberOfLogicalProcessors')}
    Memory=[pscustomobject]@{InstalledGB=$installedGB;Modules=$ramModules;FirmwareArrays=$ramArrays;Upgradeability='UNKNOWN: firmware slot/module records do not prove removable RAM.'}
    OSDisk=$osDisk;Disks=$disks;PhysicalDisks=$physicalDisks;Graphics=$video;Network=$adapters
    Batteries=$batteries;Smart=$smart;DeviceProblems=$problemDevices;Events=@($events | Sort-Object Time -Descending);MemoryTests=$memoryTests;CrashDumpInventory=$dumps
    Samples=@($samples.ToArray());ManualChecks=$manualChecks
    Setup=[pscustomobject]@{SecureBoot=$secureBoot;TPM=$tpm;HPBiosPasswordIndicators=$biosPasswords;CurrentEnrollmentIndicators=$mdmCount;AutopilotStatus='UNKNOWN: requires seller release and online setup verification.'}
    Coverage=[pscustomobject]@{RequestedHistoryDays=$HistoryDays;OldestRetainedSystemEvent=$earliest;EventLimitReached=($rawEvents.Count -ge $MaxEvents);MaxMatchingEvents=$MaxEvents;DumpAnalysisPerformed=$false;NewMemoryTestPerformed=$false;StressTestPerformed=$false;SerialsIncluded=[bool]$IncludeSerialNumbers}
    CollectionErrors=@($collectionErrors.ToArray())
}
$assessment=Get-Assessment -Data $data -MinRamGB $MinRamGB -MinDiskGB $MinDiskGB -MinIntelGeneration $MinIntelGeneration -MinIntelTier $MinIntelTier
$jsonPath=Join-Path $reportDirectory 'inspection.json'
[pscustomobject]@{Data=$data;Assessment=$assessment} | ConvertTo-Json -Depth 35 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
$lines=New-Object 'System.Collections.Generic.List[string]'
$lines.Add('LAPTOP CHECK - '+$assessment.Decision)
$lines.Add('Captured: '+$data.CapturedAt)
$lines.Add(('Machine: {0} {1}' -f $data.Computer.Manufacturer,$data.Computer.Model))
$lines.Add(('CPU: {0}; {1} cores / {2} threads' -f $data.CPU.Name,$data.CPU.Cores,$data.CPU.Threads))
$lines.Add(('RAM: {0} GiB; Windows disk: {1}' -f $installedGB,(Get-Field $osDisk 'Model' 'UNKNOWN')))
$lines.Add('')
$lines.Add('YOUR TARGETS')
foreach($r in $assessment.Requirements){$lines.Add(('  [{0}] {1}: {2} | target: {3}' -f $r.Status,$r.Name,$r.Actual,$r.Target))}
$lines.Add('');$lines.Add('EVIDENCE AND FOLLOW-UP')
foreach($f in $assessment.Findings){$lines.Add(('  [{0}] {1}: {2}' -f $f.Severity.ToUpperInvariant(),$f.Area,$f.Title));$lines.Add('    Evidence: '+$f.Evidence);$lines.Add('    Next: '+$f.Next)}
$lines.Add('');$lines.Add('MANUAL CHECKS - cannot be certified by software')
foreach($m in $manualChecks){$lines.Add(('  [{0}] {1}' -f $m.Result,$m.Name))}
$lines.Add('');$lines.Add('LIMITS: This is an inspection snapshot, not a certificate of health. Fresh/reinstalled Windows can have no useful history. SMART passes do not exclude intermittent controller faults. SSD hours/battery cycles do not establish laptop age. ACPI thermal zones may be stale and are not per-core CPU measurements. No fixes, restarts, installations or stress tests were performed.')
$lines.Add('Reports may contain hardware IDs and event messages. Serials are masked by default, but review before sharing.')
$textPath=Join-Path $reportDirectory 'READ-ME-FIRST.txt'
$lines | Set-Content -LiteralPath $textPath -Encoding UTF8
. (Join-Path $PSScriptRoot 'Report.ps1')
$html=New-InspectionHtml -Data $data -Assessment $assessment
$htmlPath=Join-Path $reportDirectory 'inspection.html'
$html | Set-Content -LiteralPath $htmlPath -Encoding UTF8
Write-Host "`n$($assessment.Decision)" -ForegroundColor $(if($assessment.Critical){'Red'}elseif($assessment.Warnings){'Yellow'}else{'Cyan'})
$assessment.Requirements | Format-Table Status,Name,Actual -AutoSize | Out-Host
Write-Host ('Findings: {0} serious / {1} warnings / {2} unknowns' -f $assessment.Critical,$assessment.Warnings,$assessment.Unknown)
foreach($f in @($assessment.Findings | Where-Object {$_.Severity -in 'critical','warning'} | Select-Object -First 8)) { Write-Host ('  - '+$f.Title) }
Write-Host "`nOpen: $htmlPath" -ForegroundColor Cyan
Write-Host "Text: $textPath"
Write-Host 'Manual inspection, ownership/setup verification and a return period remain necessary.'
exit 0
